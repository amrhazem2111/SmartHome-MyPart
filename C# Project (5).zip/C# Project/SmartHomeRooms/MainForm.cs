namespace SmartHomeRooms;

public partial class MainForm : Form
{
    private static readonly Color Accent = Color.FromArgb(108, 92, 231);
    private static readonly Color NavBack = Color.FromArgb(26, 26, 46);

    private RoomsOverviewControl? _roomsView;
    private readonly Button[] _navButtons;

    public MainForm()
    {
        InitializeComponent();
        _navButtons =
        [
            btnNavHome, btnNavRooms, btnNavDevices, btnNavSecurity,
            btnNavEnergy, btnNavAutomation, btnNavSettings
        ];
        foreach (var btn in _navButtons)
            btn.Click += NavButton_Click;
    }

    private void NavButton_Click(object? sender, EventArgs e)
    {
        if (sender is not Button clicked) return;
        HighlightNav(clicked);

        var page = clicked.Text.Trim();
        if (page == "Rooms")
        {
            ShowRoomsView();
            return;
        }

        ClearContent();
        MessageBox.Show(
            $"You selected: {page}\n\nThis section will be added as another User Control in the full Smart Home app.",
            "Smart Home",
            MessageBoxButtons.OK,
            MessageBoxIcon.Information);
    }

    private void ShowRoomsView()
    {
        ClearContent();
        _roomsView = new RoomsOverviewControl { Dock = DockStyle.Fill };
        panelContent.Controls.Add(_roomsView);
    }

    private void ClearContent()
    {
        panelContent.Controls.Clear();
        _roomsView?.Dispose();
        _roomsView = null;
    }

    private void HighlightNav(Button selected)
    {
        foreach (var btn in _navButtons)
        {
            var isSelected = btn == selected;
            btn.BackColor = isSelected ? Accent : NavBack;
            btn.Font = new Font("Segoe UI", 10F, isSelected ? FontStyle.Bold : FontStyle.Regular);
        }
    }
}
