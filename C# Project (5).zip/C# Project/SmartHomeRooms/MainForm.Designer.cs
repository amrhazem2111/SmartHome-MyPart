namespace SmartHomeRooms;

partial class MainForm
{
    private System.ComponentModel.IContainer components = null;
    private TableLayoutPanel tableLayoutRoot;
    private Panel panelSidebar;
    private Label lblSmartHomeTitle;
    private Button btnNavHome;
    private Button btnNavRooms;
    private Button btnNavDevices;
    private Button btnNavSecurity;
    private Button btnNavEnergy;
    private Button btnNavAutomation;
    private Button btnNavSettings;
    private Panel panelUser;
    private Label lblUserName;
    private Label lblUserEmail;
    private Panel panelContent;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
            components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        tableLayoutRoot = new TableLayoutPanel();
        panelSidebar = new Panel();
        lblSmartHomeTitle = new Label();
        btnNavHome = new Button();
        btnNavRooms = new Button();
        btnNavDevices = new Button();
        btnNavSecurity = new Button();
        btnNavEnergy = new Button();
        btnNavAutomation = new Button();
        btnNavSettings = new Button();
        panelUser = new Panel();
        lblUserName = new Label();
        lblUserEmail = new Label();
        panelContent = new Panel();
        tableLayoutRoot.SuspendLayout();
        panelSidebar.SuspendLayout();
        panelUser.SuspendLayout();
        SuspendLayout();

        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        BackColor = Color.FromArgb(15, 15, 35);
        ClientSize = new Size(1400, 900);
        Controls.Add(tableLayoutRoot);
        Font = new Font("Segoe UI", 9F);
        MinimumSize = new Size(900, 600);
        Name = "MainForm";
        StartPosition = FormStartPosition.CenterScreen;
        Text = "Smart Home";
        WindowState = FormWindowState.Maximized;

        tableLayoutRoot.ColumnCount = 2;
        tableLayoutRoot.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 220F));
        tableLayoutRoot.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
        tableLayoutRoot.Controls.Add(panelSidebar, 0, 0);
        tableLayoutRoot.Controls.Add(panelContent, 1, 0);
        tableLayoutRoot.Dock = DockStyle.Fill;
        tableLayoutRoot.RowCount = 1;
        tableLayoutRoot.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));

        panelSidebar.BackColor = Color.FromArgb(26, 26, 46);
        panelSidebar.Controls.Add(lblSmartHomeTitle);
        panelSidebar.Controls.Add(btnNavHome);
        panelSidebar.Controls.Add(btnNavRooms);
        panelSidebar.Controls.Add(btnNavDevices);
        panelSidebar.Controls.Add(btnNavSecurity);
        panelSidebar.Controls.Add(btnNavEnergy);
        panelSidebar.Controls.Add(btnNavAutomation);
        panelSidebar.Controls.Add(btnNavSettings);
        panelSidebar.Controls.Add(panelUser);
        panelSidebar.Dock = DockStyle.Fill;

        lblSmartHomeTitle.AutoSize = true;
        lblSmartHomeTitle.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
        lblSmartHomeTitle.ForeColor = Color.White;
        lblSmartHomeTitle.Location = new Point(16, 24);
        lblSmartHomeTitle.Text = "Smart Home";

        ConfigureNavButton(btnNavHome, "  Home", 56, false);
        ConfigureNavButton(btnNavRooms, "  Rooms", 100, false);
        ConfigureNavButton(btnNavDevices, "  Devices", 144, false);
        ConfigureNavButton(btnNavSecurity, "  Security", 188, false);
        ConfigureNavButton(btnNavEnergy, "  Energy", 232, false);
        ConfigureNavButton(btnNavAutomation, "  Automation", 276, false);
        ConfigureNavButton(btnNavSettings, "  Settings", 320, false);

        panelUser.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        panelUser.BackColor = Color.FromArgb(35, 35, 58);
        panelUser.Controls.Add(lblUserName);
        panelUser.Controls.Add(lblUserEmail);
        panelUser.Dock = DockStyle.Bottom;
        panelUser.Size = new Size(204, 56);

        lblUserName.AutoSize = true;
        lblUserName.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        lblUserName.ForeColor = Color.White;
        lblUserName.Location = new Point(12, 10);
        lblUserName.Text = "Student User";

        lblUserEmail.AutoSize = true;
        lblUserEmail.ForeColor = Color.FromArgb(180, 180, 200);
        lblUserEmail.Location = new Point(12, 30);
        lblUserEmail.Text = "student@university.edu";

        panelContent.BackColor = Color.FromArgb(15, 15, 35);
        panelContent.Dock = DockStyle.Fill;
        panelContent.Name = "panelContent";

        tableLayoutRoot.ResumeLayout(false);
        panelUser.ResumeLayout(false);
        panelSidebar.ResumeLayout(false);
        ResumeLayout(false);
    }

    private static void ConfigureNavButton(Button btn, string text, int y, bool selected)
    {
        btn.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        btn.FlatStyle = FlatStyle.Flat;
        btn.FlatAppearance.BorderSize = 0;
        btn.ForeColor = Color.White;
        btn.Location = new Point(8, y);
        btn.Size = new Size(204, 40);
        btn.Text = text;
        btn.TextAlign = ContentAlignment.MiddleLeft;
        btn.UseVisualStyleBackColor = false;
        btn.BackColor = selected ? Color.FromArgb(108, 92, 231) : Color.FromArgb(26, 26, 46);
        btn.Font = new Font("Segoe UI", 10F, selected ? FontStyle.Bold : FontStyle.Regular);
    }
}
