namespace SmartHomeRooms;

public partial class RoomControlDialog : Form
{
    public string SelectedAction => cmbAction.SelectedItem?.ToString() ?? "";

    public RoomControlDialog(string roomName)
    {
        InitializeComponent();
        lblTitle.Text = $"More controls — {roomName}";
        Text = $"Smart Home — {roomName}";
    }
}
