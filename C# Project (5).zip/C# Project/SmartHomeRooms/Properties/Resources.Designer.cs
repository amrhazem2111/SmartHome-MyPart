namespace SmartHomeRooms.Properties;

internal static class Resources
{
    private static global::System.Resources.ResourceManager resourceMan;

    internal static global::System.Resources.ResourceManager ResourceManager =>
        resourceMan ??= new global::System.Resources.ResourceManager(
            "SmartHomeRooms.Properties.Resources",
            typeof(Resources).Assembly);

    internal static global::System.Drawing.Bitmap LivingRoom =>
        (global::System.Drawing.Bitmap)ResourceManager.GetObject("LivingRoom", null)!;

    internal static global::System.Drawing.Bitmap Bedroom =>
        (global::System.Drawing.Bitmap)ResourceManager.GetObject("Bedroom", null)!;

    internal static global::System.Drawing.Bitmap Kitchen =>
        (global::System.Drawing.Bitmap)ResourceManager.GetObject("Kitchen", null)!;

    internal static global::System.Drawing.Bitmap Bathroom =>
        (global::System.Drawing.Bitmap)ResourceManager.GetObject("Bathroom", null)!;

    internal static global::System.Drawing.Bitmap Garage =>
        (global::System.Drawing.Bitmap)ResourceManager.GetObject("Garage", null)!;
}
