# Smart Home — Rooms Overview

Windows Forms — **`MainForm`** (Form) + **`RoomsOverviewControl`** (User Control). الأحداث في **`RoomsOverviewControl.cs`**.

## «متجاوب» = الأزرار ترد

| لما تدوسي | إيه اللي يحصل |
|-----------|----------------|
| **Lights On / AC On / …** | اللون يتغيّر + رسالة تأكيد (ON/OFF) |
| **...** | نافذة صغيرة (Save / Cancel) زي الـ popup في التاسك |
| **★** | النجمة تتفعّل / تتشال |
| **Home, Devices, …** | القائمة تتظلّل + رسالة توضيح |

## افتحي المشروع

**`e:\cursor\C# Project\SmartHomeRooms.sln`** → **F5**

المشروع على **.NET 9** (`net9.0-windows`).

## هيكل المشروع (حسب Team Leader)

| الملف | النوع | الدور |
|-------|--------|--------|
| **`MainForm`** | **Form** | قائمة جانبية + **`panelContent` فاضي** — زي `main` في مشروع التيم |
| **`RoomsOverviewControl`** | **User Control** | يظهر **بس لما تدوسي Rooms** |
| **`RoomControlDialog`** | **Form** | Popup لما تدوسي **...** |
| **`Resources/`** | صور | PNG للغرف |

في **Solution Explorer** هتشوفي:
- `MainForm.cs` → Form
- `RoomsOverviewControl.cs` → User Control (مع `.Designer.cs` و `.resx`)

## ملاحظات Team Leader

| قال إيه | عندنا |
|---------|--------|
| الشاشة **User Control** + **Form** للتطبيق | `RoomsOverviewControl` + `MainForm` |
| الصور جوا **Resources** | `SmartHomeRooms/Resources/*.png` |
| **PictureBox** + **Resources.resx** | على كل بطاقة غرفة |

استبدلي صور الـ PNG في **`Resources/`** بصور حقيقية لو عندك — **نفس الأسماء**.

- **واجهة Rooms:** `RoomsOverviewControl.Designer.cs`
- **تفاعل الأزرار:** `RoomsOverviewControl.cs` + `RoomControlDialog`
