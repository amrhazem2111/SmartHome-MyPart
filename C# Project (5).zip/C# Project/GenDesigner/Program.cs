using System.Text;

var path = @"e:\cursor\C# Project\SmartHomeRooms\RoomsOverviewForm.Designer.cs";
var sb = new StringBuilder();
void L(string s) => sb.AppendLine(s);

L("namespace SmartHomeRooms;");
L("");
L("partial class RoomsOverviewForm");
L("{");
L("    private System.ComponentModel.IContainer components = null;");
L("");
L("    protected override void Dispose(bool disposing)");
L("    {");
L("        if (disposing && (components != null))");
L("            components.Dispose();");
L("        base.Dispose(disposing);");
L("    }");
L("");
L("    #region Windows Form Designer generated code");
L("");
L("    private void InitializeComponent()");
L("    {");

foreach (var d in new[]
{
    "tableLayoutRoot = new TableLayoutPanel();",
    "panelSidebar = new Panel();",
    "lblSmartHomeTitle = new Label();",
    "btnNavHome = new Button();", "btnNavRooms = new Button();", "btnNavDevices = new Button();",
    "btnNavSecurity = new Button();", "btnNavEnergy = new Button();", "btnNavAutomation = new Button();",
    "btnNavSettings = new Button();",
    "panelUser = new Panel();", "lblUserName = new Label();", "lblUserEmail = new Label();",
    "tableLayoutMain = new TableLayoutPanel();",
    "panelHeader = new Panel();",
    "lblRoomsOverview = new Label();", "lblSubtitle = new Label();",
    "flowStats = new FlowLayoutPanel();",
    "flowRoomCards = new FlowLayoutPanel();",
}) L($"        {d}");

L("        tableLayoutRoot.SuspendLayout();");
L("        panelSidebar.SuspendLayout();");
L("        panelUser.SuspendLayout();");
L("        tableLayoutMain.SuspendLayout();");
L("        panelHeader.SuspendLayout();");
L("        SuspendLayout();");

L("        AutoScaleDimensions = new SizeF(7F, 15F);");
L("        AutoScaleMode = AutoScaleMode.Font;");
L("        BackColor = Color.FromArgb(15, 15, 35);");
L("        ClientSize = new Size(1400, 900);");
L("        Controls.Add(tableLayoutRoot);");
L("        Font = new Font(\"Segoe UI\", 9F);");
L("        MinimumSize = new Size(900, 600);");
L("        Name = \"RoomsOverviewForm\";");
L("        StartPosition = FormStartPosition.CenterScreen;");
L("        Text = \"Smart Home - Rooms Overview\";");
L("        WindowState = FormWindowState.Maximized;");

L("        tableLayoutRoot.ColumnCount = 2;");
L("        tableLayoutRoot.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 220F));");
L("        tableLayoutRoot.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));");
L("        tableLayoutRoot.Controls.Add(panelSidebar, 0, 0);");
L("        tableLayoutRoot.Controls.Add(tableLayoutMain, 1, 0);");
L("        tableLayoutRoot.Dock = DockStyle.Fill;");
L("        tableLayoutRoot.RowCount = 1;");
L("        tableLayoutRoot.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));");

L("        panelSidebar.BackColor = Color.FromArgb(26, 26, 46);");
L("        panelSidebar.Controls.Add(lblSmartHomeTitle);");
L("        panelSidebar.Controls.Add(panelUser);");
L("        panelSidebar.Dock = DockStyle.Fill;");

var nav = new[] { "Home", "Rooms", "Devices", "Security", "Energy", "Automation", "Settings" };
var fields = new[] { "btnNavHome", "btnNavRooms", "btnNavDevices", "btnNavSecurity", "btnNavEnergy", "btnNavAutomation", "btnNavSettings" };
var y = 56;
for (var i = 0; i < nav.Length; i++)
{
    var field = fields[i];
    var text = nav[i];
    L($"        panelSidebar.Controls.Add({field});");
    L($"        {field}.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;");
    L($"        {field}.FlatStyle = FlatStyle.Flat;");
    L($"        {field}.FlatAppearance.BorderSize = 0;");
    L($"        {field}.ForeColor = Color.White;");
    L($"        {field}.Location = new Point(8, {y});");
    L($"        {field}.Size = new Size(204, 40);");
    L($"        {field}.Text = \"  {text}\";");
    L($"        {field}.TextAlign = ContentAlignment.MiddleLeft;");
    L($"        {field}.UseVisualStyleBackColor = false;");
    if (text == "Rooms")
    {
        L($"        {field}.BackColor = Color.FromArgb(108, 92, 231);");
        L($"        {field}.Font = new Font(\"Segoe UI\", 10F, FontStyle.Bold);");
    }
    else
    {
        L($"        {field}.BackColor = Color.FromArgb(26, 26, 46);");
        L($"        {field}.Font = new Font(\"Segoe UI\", 10F);");
    }
    y += 44;
}

L("        lblSmartHomeTitle.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;");
L("        lblSmartHomeTitle.AutoSize = true;");
L("        lblSmartHomeTitle.Font = new Font(\"Segoe UI\", 14F, FontStyle.Bold);");
L("        lblSmartHomeTitle.ForeColor = Color.White;");
L("        lblSmartHomeTitle.Location = new Point(16, 24);");
L("        lblSmartHomeTitle.Text = \"Smart Home\";");

L("        panelUser.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;");
L("        panelUser.BackColor = Color.FromArgb(35, 35, 58);");
L("        panelUser.Controls.Add(lblUserName);");
L("        panelUser.Controls.Add(lblUserEmail);");
L("        panelUser.Location = new Point(8, 0);");
L("        panelUser.Size = new Size(204, 56);");
L("        panelUser.Dock = DockStyle.Bottom;");
L("        lblUserName.AutoSize = true; lblUserName.ForeColor = Color.White;");
L("        lblUserName.Font = new Font(\"Segoe UI\", 10F, FontStyle.Bold);");
L("        lblUserName.Text = \"Student User\"; lblUserName.Location = new Point(12, 10);");
L("        lblUserEmail.AutoSize = true; lblUserEmail.ForeColor = Color.FromArgb(180, 180, 200);");
L("        lblUserEmail.Text = \"student@university.edu\"; lblUserEmail.Location = new Point(12, 30);");

L("        tableLayoutMain.ColumnCount = 1;");
L("        tableLayoutMain.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));");
L("        tableLayoutMain.Controls.Add(panelHeader, 0, 0);");
L("        tableLayoutMain.Controls.Add(flowStats, 0, 1);");
L("        tableLayoutMain.Controls.Add(flowRoomCards, 0, 2);");
L("        tableLayoutMain.Dock = DockStyle.Fill;");
L("        tableLayoutMain.Padding = new Padding(24, 16, 24, 16);");
L("        tableLayoutMain.RowCount = 3;");
L("        tableLayoutMain.RowStyles.Add(new RowStyle(SizeType.AutoSize));");
L("        tableLayoutMain.RowStyles.Add(new RowStyle(SizeType.AutoSize));");
L("        tableLayoutMain.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));");

L("        panelHeader.AutoSize = true;");
L("        panelHeader.AutoSizeMode = AutoSizeMode.GrowAndShrink;");
L("        panelHeader.Controls.Add(lblRoomsOverview);");
L("        panelHeader.Controls.Add(lblSubtitle);");
L("        panelHeader.Dock = DockStyle.Fill;");
L("        panelHeader.MinimumSize = new Size(0, 64);");

L("        lblRoomsOverview.AutoSize = true;");
L("        lblRoomsOverview.Font = new Font(\"Segoe UI\", 22F, FontStyle.Bold);");
L("        lblRoomsOverview.ForeColor = Color.White;");
L("        lblRoomsOverview.Location = new Point(0, 0);");
L("        lblRoomsOverview.Text = \"Rooms Overview\";");
L("        lblSubtitle.AutoSize = true;");
L("        lblSubtitle.ForeColor = Color.FromArgb(180, 180, 200);");
L("        lblSubtitle.Location = new Point(2, 38);");
L("        lblSubtitle.Text = \"Manage and control all rooms in your smart home.\";");

L("        flowStats.AutoSize = true;");
L("        flowStats.AutoSizeMode = AutoSizeMode.GrowAndShrink;");
L("        flowStats.Dock = DockStyle.Fill;");
L("        flowStats.WrapContents = true;");
L("        flowStats.BackColor = Color.FromArgb(15, 15, 35);");
L("        flowStats.Padding = new Padding(0, 8, 0, 8);");

(string prefix, string val, string cap, string? badge)[] stats =
{
    ("statRooms", "4 / 5", "Rooms Active", "Online"),
    ("statTemp", "22°C", "Avg. Temperature", null),
    ("statLights", "12", "Total Lights", null),
    ("statDevices", "24", "Total Devices", null),
};
foreach (var (prefix, val, cap, badge) in stats)
{
    L($"        {prefix} = new Panel(); {prefix}_val = new Label(); {prefix}_cap = new Label();");
    if (badge != null) L($"        {prefix}_badge = new Label();");
    L($"        {prefix}.BackColor = Color.FromArgb(40, 40, 70); {prefix}.Size = new Size(200, 64); {prefix}.Margin = new Padding(0, 0, 16, 8);");
    L($"        {prefix}.Controls.Add({prefix}_val); {prefix}.Controls.Add({prefix}_cap);");
    if (badge != null) L($"        {prefix}.Controls.Add({prefix}_badge);");
    L($"        {prefix}_val.Text = \"{val}\"; {prefix}_val.ForeColor = Color.White;");
    L($"        {prefix}_val.Font = new Font(\"Segoe UI\", 14F, FontStyle.Bold); {prefix}_val.Location = new Point(12, 10); {prefix}_val.AutoSize = true;");
    L($"        {prefix}_cap.Text = \"{cap}\"; {prefix}_cap.ForeColor = Color.FromArgb(180, 180, 200); {prefix}_cap.Location = new Point(12, 36); {prefix}_cap.AutoSize = true;");
    if (badge != null)
        L($"        {prefix}_badge.Text = \"● {badge}\"; {prefix}_badge.ForeColor = Color.LightGreen; {prefix}_badge.Location = new Point(120, 12); {prefix}_badge.AutoSize = true;");
    L($"        flowStats.Controls.Add({prefix});");
}

L("        flowRoomCards.AutoScroll = true;");
L("        flowRoomCards.BackColor = Color.FromArgb(15, 15, 35);");
L("        flowRoomCards.Dock = DockStyle.Fill;");
L("        flowRoomCards.WrapContents = true;");
L("        flowRoomCards.Padding = new Padding(0, 8, 0, 0);");

var rooms = new (int idx, string name, string desc, string temp, string status, bool online, (int r, int g, int b) tint, int lights, int devices, string resName, (string t, bool on)[] buttons)[]
{
    (1, "Living Room", "Main entertainment area", "22°C", "Online", true, (80, 60, 120), 4, 6, "LivingRoom",
     new[] { ("Lights On", true), ("AC On", true), ("TV On", true), ("...", false) }),
    (2, "Bedroom", "Rest and relaxation", "20°C", "Online", true, (50, 70, 100), 2, 4, "Bedroom",
     new[] { ("Night Mode", true), ("Lights Off", false), ("Blinds Closed", false), ("...", false) }),
    (3, "Kitchen", "Cooking and dining", "24°C", "Online", true, (90, 75, 55), 3, 5, "Kitchen",
     new[] { ("Lights On", true), ("Hood On", true), ("Coffee Ready", true), ("...", false) }),
    (4, "Bathroom", "Personal hygiene", "21°C", "Standby", false, (45, 85, 95), 2, 3, "Bathroom",
     new[] { ("Heater Off", false), ("Lights Off", false), ("Fan Off", false), ("...", false) }),
    (5, "Garage", "Vehicle storage", "18°C", "Standby", false, (55, 55, 60), 1, 2, "Garage",
     new[] { ("Lights Off", false), ("Door Closed", false), ("Charger Standby", false), ("...", false) }),
};

foreach (var (idx, name, desc, temp, status, online, tint, lights, devices, resName, buttons) in rooms)
{
    var p = $"card{idx}";
    L($"        {p} = new Panel(); {p}_status = new Label(); {p}_star = new Button(); {p}_pic = new PictureBox();");
    L($"        {p}_name = new Label(); {p}_desc = new Label(); {p}_temp = new Label(); {p}_counts = new Label();");
    L($"        {p}.BackColor = Color.FromArgb(40, 40, 70); {p}.MinimumSize = new Size(300, 380); {p}.Size = new Size(320, 400); {p}.Margin = new Padding(0, 0, 20, 20);");
    var sc = online ? "Color.LightGreen" : "Color.FromArgb(108, 92, 231)";
    L($"        {p}_status.Text = \"● {status}\"; {p}_status.ForeColor = {sc}; {p}_status.Location = new Point(12, 8); {p}_status.AutoSize = true;");
    L($"        {p}_star.Text = \"★\"; {p}_star.FlatStyle = FlatStyle.Flat; {p}_star.FlatAppearance.BorderSize = 0;");
    L($"        {p}_star.BackColor = Color.FromArgb(40, 40, 70); {p}_star.ForeColor = Color.Gold; {p}_star.Location = new Point(272, 4); {p}_star.Size = new Size(32, 28);");
    L($"        {p}_pic.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;");
    L($"        {p}_pic.Location = new Point(12, 36); {p}_pic.Size = new Size(296, 140);");
    L($"        {p}_pic.SizeMode = PictureBoxSizeMode.StretchImage;");
    L($"        {p}_pic.Image = SmartHomeRooms.Properties.Resources.{resName};");
    L($"        {p}_name.Text = \"{name}\"; {p}_name.ForeColor = Color.White; {p}_name.Font = new Font(\"Segoe UI\", 12F, FontStyle.Bold); {p}_name.Location = new Point(12, 188); {p}_name.AutoSize = true;");
    L($"        {p}_desc.Text = \"{desc}\"; {p}_desc.ForeColor = Color.FromArgb(180, 180, 200); {p}_desc.Location = new Point(12, 212); {p}_desc.AutoSize = true;");
    L($"        {p}_temp.Anchor = AnchorStyles.Top | AnchorStyles.Right;");
    L($"        {p}_temp.Text = \"{temp}\"; {p}_temp.ForeColor = Color.White; {p}_temp.Location = new Point(260, 188); {p}_temp.AutoSize = true;");
    L($"        {p}_counts.Text = \"Lights: {lights}   Devices: {devices}\"; {p}_counts.ForeColor = Color.FromArgb(180, 180, 200); {p}_counts.Location = new Point(12, 238); {p}_counts.AutoSize = true;");
    L($"        {p}.Controls.Add({p}_status); {p}.Controls.Add({p}_star); {p}.Controls.Add({p}_pic);");
    L($"        {p}.Controls.Add({p}_name); {p}.Controls.Add({p}_desc); {p}.Controls.Add({p}_temp); {p}.Controls.Add({p}_counts);");
    var bx = 12; var by = 268; var bi = 0;
    foreach (var (bt, active) in buttons)
    {
        var bn = $"{p}_btn{bi}";
        L($"        {bn} = new Button();");
        L($"        {bn}.Anchor = AnchorStyles.Top | AnchorStyles.Left;");
        L($"        {bn}.Text = \"{bt}\"; {bn}.FlatStyle = FlatStyle.Flat; {bn}.FlatAppearance.BorderSize = 0; {bn}.ForeColor = Color.White; {bn}.Size = new Size(140, 36); {bn}.Location = new Point({bx}, {by});");
        var bc = active ? "Color.FromArgb(108, 92, 231)" : "Color.FromArgb(55, 55, 85)";
        L($"        {bn}.BackColor = {bc}; {bn}.UseVisualStyleBackColor = false;");
        L($"        {p}.Controls.Add({bn});");
        bi++;
        if (bi % 2 == 0) { bx = 12; by += 44; } else bx = 160;
    }
    L($"        flowRoomCards.Controls.Add({p});");
}

L("        panelHeader.ResumeLayout(false); panelHeader.PerformLayout();");
L("        tableLayoutMain.ResumeLayout(false); tableLayoutMain.PerformLayout();");
L("        panelUser.ResumeLayout(false); panelUser.PerformLayout();");
L("        panelSidebar.ResumeLayout(false); panelSidebar.PerformLayout();");
L("        tableLayoutRoot.ResumeLayout(false);");
L("        ResumeLayout(false);");
L("    }");
L("");
L("    #endregion");
L("");
L("    private TableLayoutPanel tableLayoutRoot;");
L("    private Panel panelSidebar;");
L("    private Label lblSmartHomeTitle;");
L("    private Button btnNavHome, btnNavRooms, btnNavDevices, btnNavSecurity, btnNavEnergy, btnNavAutomation, btnNavSettings;");
L("    private Panel panelUser;");
L("    private Label lblUserName, lblUserEmail;");
L("    private TableLayoutPanel tableLayoutMain;");
L("    private Panel panelHeader;");
L("    private Label lblRoomsOverview, lblSubtitle;");
L("    private FlowLayoutPanel flowStats, flowRoomCards;");
L("    private Panel statRooms, statTemp, statLights, statDevices;");
L("    private Label statRooms_val, statRooms_cap, statRooms_badge, statTemp_val, statTemp_cap, statLights_val, statLights_cap, statDevices_val, statDevices_cap;");
for (var idx = 1; idx <= 5; idx++)
{
    L($"    private Panel card{idx};");
    L($"    private Label card{idx}_status, card{idx}_name, card{idx}_desc, card{idx}_temp, card{idx}_counts;");
    L($"    private Button card{idx}_star; private PictureBox card{idx}_pic;");
    L($"    private Button card{idx}_btn0, card{idx}_btn1, card{idx}_btn2, card{idx}_btn3;");
}
L("}");

File.WriteAllText(path, sb.ToString());
Console.WriteLine("Generated responsive designer: " + path);
